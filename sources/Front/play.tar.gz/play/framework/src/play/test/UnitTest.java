package play.test;

public class UnitTest extends BaseTest {

}
